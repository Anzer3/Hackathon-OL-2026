## 7.3 Kontroly

* Souborů ve výstupu: 401 (očekáváno 401)
* Data predikce změněná proti originálu: 0 souborů (očekáváno 0; porovnáno bajt po bajtu bez pole doporuceni)
* Každá obec má 5 oblastí, velká města mají varování a nemají dostupnost, stav_2025 = součet ročníků 2025, žádné NaN: OK
* Velká města (> 15 000 obyv. v 2025): Hranice, Olomouc, Prostějov, Přerov, Šumperk

### Rozložení barev

|                     |   ms |   zs |   pldd |   pl |   sen |
|:--------------------|-----:|-----:|-------:|-----:|------:|
| 🔴 výrazný růst      |    0 |    0 |      0 |    7 |   233 |
| 🟠 růst              |    0 |    0 |      0 |   14 |   114 |
| 🔵 pokles            |  161 |  296 |    235 |   69 |     0 |
| 🟢 bez výrazné změny |  240 |  105 |    166 |  311 |    54 |

### Špatná dostupnost (VHD > 30 min), počet obcí

* ms: hodnoceno 119, špatná 15
* zs: hodnoceno 186, špatná 21
* pldd: hodnoceno 396, špatná 79
* pl: hodnoceno 396, špatná 46

### Rejstřík vs. dojížďka do škol (MOB_DOJ_SKOLY, rok 2022)

* Obce s MŠ nebo ZŠ v rejstříku: 285; obce s ≥ 20 dojíždějícími do škol: 197
* Odchylky: 88 (z toho „škola, ale < 20 dojíždějících“: 88, „bez školy, ale ≥ 20“: 0) → kontrola_dojizdka.csv
* Pozn.: MOB_DOJ_SKOLY zahrnuje dojíždějící do všech škol (i SŠ, VŠ) ze sčítání 2021, proto jde jen o hrubou kontrolu.

## 7.2 Citlivost prahů

Počet obcí (z 401), které změní barvu semaforu oproti základním prahům:

| varianta              |   ms |   zs |   pldd |   pl |   sen |
|:----------------------|-----:|-----:|-------:|-----:|------:|
| min. počet osob × 2   |   52 |  104 |     98 |   30 |    66 |
| min. počet osob × 0,5 |    4 |   65 |     27 |   29 |    29 |

Počet obcí, kterým se změní značka „⚠ špatná dostupnost“ (z hodnocených):

| hranice VHD   | ms       | zs       | pldd      | pl        |
|:--------------|:---------|:---------|:----------|:----------|
| 20 min        | 44 / 119 | 70 / 186 | 213 / 396 | 161 / 396 |
| 45 min        | 12 / 119 | 17 / 186 | 60 / 396  | 35 / 396  |

Pozn.: vrstvy mají pásma 15 / 30 / (35) / 45 / 60 min, hranice 20 min se proto chová stejně jako 15 min (obec v pásmu 15–30 min nelze rozlišit na „do 20“ a „20–30“).

## 7.2 Zpětná trefa

Viz nejistota_backtest.md (skript s6_nejistota_backtest.py).
