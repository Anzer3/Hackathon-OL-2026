# Karta „Doporučení“ – implementace do dema (Next.js + TSX)

**Výchozí stav:** demo už načítá `obce/<kód>.json` a zobrazuje mapu. Přibývá jen pole `doporuceni` ve stejném souboru → **žádné nové načítání, žádný nový endpoint**.

**Úkol:** vyměnit soubory obcí za nové (s `doporuceni`) a přidat kartu pod / vedle výpisu obce. Mapa ani stávající komponenty se nemění.

---

## 1. Data

1. Nahradit `public/data/obce/*.json` soubory ze `doporuceni-vystup.zip` (složka `obce/`, 401 souborů). `obce.json` je beze změny.
2. Predikce v souborech je stejná jako dosud (ověřeno) → stávající grafy se nezmění.
3. Soubory jsou o ~5 kB větší (celkem 12,7 MB místo 10,6 MB).

---

## 2. Typy (`types/doporuceni.ts`)

```ts
export type Klic = 'ms' | 'zs' | 'pldd' | 'pl' | 'sen';
export type Uroven = 'vyrazny_rust' | 'rust' | 'pokles' | 'ok';

export interface RokHodnota { rok: number; hodnota: number }

export interface Oblast {
  klic: Klic;
  nazev: string;              // "Mateřská škola"
  vek: string;                // "3–5"
  obdobi: [number, number];   // [2026, 2031]
  v_obci: boolean | null;     // má obec MŠ/ZŠ (null u lékařů a seniorů)
  zarizeni_v_obci: { nazev: string; kapacita: number | null }[] | null;
  nejblizsi_obec: string | null;
  dostupnost: { auto_min: number | null; vhd_min: number | null; pesi_m: number | null } | null;
  spatna_dostupnost: boolean | null;
  rada: { roky: number[]; hodnoty: number[] };
  stav_2025: RokHodnota;
  max: RokHodnota;
  min: RokHodnota;
  konec: RokHodnota;
  zmena_pct_max: number | null;
  zmena_pct_min: number | null;
  zmena_pct_konec: number | null;
  nejistota_pct: number;
  uroven: Uroven;
  podil_65_plus?: { '2025': number | null; konec: number | null };  // jen pl
  poradi_kraj_pct?: number | null;                                  // jen sen
  texty: string[];            // hotové věty – zobrazit beze změny
  zdroje: string[];
}

export interface Doporuceni {
  velke_mesto: boolean;
  varovani: string | null;
  oblasti: Oblast[];          // vždy 5, pořadí ms, zs, pldd, pl, sen
}
```

Do existujícího typu dat obce přidat `doporuceni: Doporuceni`.

---

## 3. Komponenty

| Soubor | Co dělá |
|---|---|
| `components/doporuceni/DoporuceniKarta.tsx` | varování velkého města + 5× `OblastRadek` + `PravidlaVysvetleni` |
| `components/doporuceni/OblastRadek.tsx` | semafor, značka ⚠, název a věk, `MiniGraf`, texty, zdroje |
| `components/doporuceni/MiniGraf.tsx` | malý SVG graf z `stav_2025` + `rada` (bez knihovny) |
| `components/doporuceni/PravidlaVysvetleni.tsx` | statický text pravidel (kap. 5) |

Karta nezávisí na zvoleném roce → nepředávat jí rok, nepřepočítávat při změně roku.

### `DoporuceniKarta.tsx`

```tsx
import type { Doporuceni } from '@/types/doporuceni';
import { OblastRadek } from './OblastRadek';
import { PravidlaVysvetleni } from './PravidlaVysvetleni';

export function DoporuceniKarta({ data }: { data?: Doporuceni }) {
  if (!data) return null;                       // staré soubory bez doporuceni
  return (
    <section className="doporuceni">
      <h2>Doporučení</h2>
      {data.varovani && <p className="doporuceni-varovani">{data.varovani}</p>}
      {data.oblasti.map((o) => <OblastRadek key={o.klic} oblast={o} />)}
      <PravidlaVysvetleni />
    </section>
  );
}
```

### `OblastRadek.tsx`

```tsx
import type { Oblast, Uroven } from '@/types/doporuceni';
import { MiniGraf } from './MiniGraf';

export const SEMAFOR: Record<Uroven, { barva: string; popis: string }> = {
  vyrazny_rust: { barva: '#d32f2f', popis: 'Výrazný růst' },
  rust:         { barva: '#f57c00', popis: 'Růst' },
  pokles:       { barva: '#1976d2', popis: 'Pokles' },
  ok:           { barva: '#388e3c', popis: 'Bez výrazné změny' },
};

export function OblastRadek({ oblast: o }: { oblast: Oblast }) {
  const s = SEMAFOR[o.uroven];
  return (
    <article className="oblast">
      <header>
        <span className="semafor" style={{ background: s.barva }} aria-hidden />
        <strong>{o.nazev}</strong> <span>({o.vek} let)</span>
        <span className="uroven">{s.popis}</span>
        {o.spatna_dostupnost && <span className="znacka-dostupnost">⚠ špatná dostupnost</span>}
      </header>
      <MiniGraf oblast={o} barva={s.barva} />
      <ul>{o.texty.map((t, i) => <li key={i}>{t}</li>)}</ul>
      <p className="zdroj">Zdroj: {o.zdroje.join('; ')}</p>
    </article>
  );
}
```

* Barvu nesmí nést jen kolečko → vedle vždy text úrovně (`s.popis`).
* Texty jsou hotové (čísla zaokrouhlená, „odhadem“, nejistota) → nic neskládat ani nepřepočítávat.

### `MiniGraf.tsx`

```tsx
import type { Oblast } from '@/types/doporuceni';

export function MiniGraf({ oblast: o, barva, w = 160, h = 40 }:
  { oblast: Oblast; barva: string; w?: number; h?: number }) {
  const roky = [o.stav_2025.rok, ...o.rada.roky];
  const hod = [o.stav_2025.hodnota, ...o.rada.hodnoty];
  const lo = Math.min(...hod), hi = Math.max(...hod);
  const x = (i: number) => (i / (roky.length - 1)) * (w - 4) + 2;
  const y = (v: number) => hi === lo ? h / 2 : h - 2 - ((v - lo) / (hi - lo)) * (h - 4);
  const d = hod.map((v, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(' ');
  return (
    <svg width={w} height={h} role="img"
         aria-label={`${o.nazev}: ${roky[0]}–${roky[roky.length - 1]}`}>
      <line x1={2} x2={w - 2} y1={y(hod[0])} y2={y(hod[0])} stroke="#bbb" strokeDasharray="3 3" />
      <path d={d} fill="none" stroke={barva} strokeWidth={2} />
      <title>{roky.map((r, i) => `${r}: ${Math.round(hod[i])}`).join('\n')}</title>
    </svg>
  );
}
```

* Čárkovaná čára = stav 2025. Osa Y je od minima řady (jen tvar vývoje), čísla jsou v textech.
* U seniorů je řada 30 let – graf stejné šířky, jen hustší.

### Kam kartu dát

Do stránky / komponenty, kde už je vybraná obec a její data:

```tsx
<DoporuceniKarta data={obec?.doporuceni} />
```

Pokud je stránka server component a data se načítají na klientovi, karta nepotřebuje `'use client'` (nemá stav), stačí ji vykreslit uvnitř stávající klientské komponenty.

---

## 4. Styl

Použít stávající styly dema (Tailwind / CSS moduly – podle toho, co demo má). Minimum:
* `.semafor` – kolečko 12 px, `border-radius: 50%`, `display: inline-block`.
* `.znacka-dostupnost` – výrazná značka (žluté pozadí, tmavý text).
* `.doporuceni-varovani` – rámeček nahoře na kartě.
* `.zdroj` – menší šedé písmo.

---

## 5. `PravidlaVysvetleni.tsx` – text pod kartou

```tsx
export function PravidlaVysvetleni() {
  return (
    <details className="pravidla">
      <summary>Jak doporučení vznikají</summary>
      <ul>
        <li>Barva ukazuje jen vývoj počtu obyvatel obce v cílovém věku podle predikce, proti odhadu pro rok 2025.</li>
        <li>Výrazná změna = změna v % je větší než nejistota predikce a zároveň alespoň minimální počet osob
            (MŠ a ZŠ 5, dětský lékař 20, praktický lékař 50, senioři 5).</li>
        <li>Červená: růst větší než 2× nejistota. Oranžová: růst větší než nejistota.
            Modrá: pokles větší než nejistota. Zelená: bez výrazné změny.</li>
        <li>Nejistota = chyba predikce ověřená zpětně (backtest 2012 → 2020): u 80 % obcí stejné velikosti
            byla chyba menší. Ověřeno do 8 let, delší výhled je orientační.
            Zpětně sedí směr doporučení v 74 % případů.</li>
        <li>⚠ špatná dostupnost = nejbližší zařízení je veřejnou dopravou dál než 30 min.
            U MŠ a ZŠ se hodnotí jen u obcí bez vlastní školy. U velkých měst a u seniorů se nehodnotí.</li>
        <li>Počty dětí a seniorů pro rok 2025 jsou odhad (za obce existují jen 3 věkové skupiny).</li>
        <li>Nepočítají se kapacity ani spádovost škol; kapacita z rejstříku je jen informace.</li>
      </ul>
    </details>
  );
}
```

---

## 6. Kontrola před demem

| Obec | Co ověřit |
|---|---|
| Olomouc | varování nahoře, žádná značka ⚠, u MŠ/ZŠ souhrnná věta o počtu škol |
| Grygov | ⚠ u dětského i praktického lékaře |
| Šumvald | ⚠ u dětského lékaře, senioři 🟠 |
| Krčmaň | ZŠ: „Obec nemá vlastní ZŠ…“ |
| Kozlov | MŠ i ZŠ: nejbližší obec s MŠ / se ZŠ |
| Lipová (obě) | různé karty podle `kod` |

* Změna roku v demu kartu nemění.
* Žádné `undefined` v textech; karta se vykreslí u všech 401 obcí (stačí projít výběr obcí v rychlém sledu).
* Běží bez internetu (`npm run build` + `npm run start`).

---

## 7. Volitelně: obarvení mapy

Mapa může obarvit obce podle `uroven` zvolené oblasti (přepínač MŠ / ZŠ / … ). Načítat kvůli tomu 401 souborů je zbytečné → vyžádat si od datového týmu malý souhrnný soubor `doporuceni-souhrn.json` (`{ kod: { ms: "pokles", …, ms_dost: true, … } }`, ~30 kB). Není součástí plánu, jen další krok.
