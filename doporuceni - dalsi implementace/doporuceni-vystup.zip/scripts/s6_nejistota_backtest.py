"""Kap. 3.3 (plná varianta) a 7.2 (zpětná trefa) nad existujícím modelem a backtestem.

Spuštění:  python3 s6_nejistota_backtest.py <složka s model.py> OUT
Používá z model.py totéž API jako backtest.py: nacti(), projekce(T, faktory, d), SKUPINY.

1. 80. percentil APE obcí (model s faktory, T = 2012 -> 2020, horizont 8 let) podle velikosti × 0–14/15–64/65+.
2. Poměr chyby úzké skupiny k chybě celé skupiny na ORP: predikce obcí sečtené do ORP (obec_orp.csv,
   vazba 2016–2022) proti skutečným ročníkům ORP; T = 2012, roky 2016–2020 (h = 4–8) a T = 2016, roky 2017–2020.
   Poměr = průměr APE úzké skupiny / průměr APE celé skupiny.
3. Nejistota oblasti = P80 skupiny × poměr (celé %) -> OUT/nejistota.csv (přepíše zálohu).
4. Zpětná trefa: pravidla semaforu na T = 2012, roky 2013–2020, skupiny 0–14 a 65+ (min. 5 osob,
   nejistota = P80 skupiny dané velikosti), predikce vs. skutečnost -> OUT/zpetna_trefa.md
"""
import sys
import numpy as np
import pandas as pd

MODEL_DIR, OUT = sys.argv[1], sys.argv[2]
sys.path.insert(0, MODEL_DIR)
sys.path.insert(0, '/home/claude/scripts')
from model import nacti, projekce, SKUPINY        # noqa: E402
import s4_doporuceni as S                          # noqa: E402

TRIDY = [('< 500', 0, 500), ('500–1 999', 500, 2000), ('2 000+', 2000, 1e12)]
SK_NAZ = ['0-14', '15-64', '65+']
UZKE = {'ms': (3, 5, 0), 'zs': (6, 10, 0), 'pldd': (0, 18, 0), 'pl': (19, 100, 1), 'sen': (80, 100, 2)}
L = []
def p(*a):
    s = ' '.join(str(x) for x in a); print(s); L.append(s)

d = nacti()
kody = list(map(str, d.obce_kody))
R = {T: projekce(T, faktory=True, d=d) for T in (2012, 2016)}


def trida(n):
    for nm, a, b in TRIDY:
        if a <= n < b:
            return nm


def act_skup(rok):                       # [N,3] skutečnost 0–14, 15–64, 65+
    return np.nansum(d.obce_skup[rok], axis=1)


def pred_skup(T, rok):                   # [N,3]
    X = R[T].obce[rok - T].sum(1)
    return np.column_stack([X[:, sl].sum(1) for sl in SKUPINY])


# ---------------------------------------------------------------- 1. P80 obcí
T, rok = 2012, 2020
ok = R[T].existuje & ~np.isnan(d.obce_celkem[rok])
A, Pp = act_skup(rok), pred_skup(T, rok)
vel = d.obce_celkem[T]
rows = []
for i in np.nonzero(ok)[0]:
    for g in range(3):
        if A[i, g] > 0:
            rows.append(dict(kod=kody[i], trida=trida(vel[i]), skupina=SK_NAZ[g],
                             ape=abs(Pp[i, g] - A[i, g]) / A[i, g] * 100))
ape = pd.DataFrame(rows)
p80 = ape.groupby(['skupina', 'trida']).ape.quantile(0.8).unstack()
mape = ape.groupby(['skupina', 'trida']).ape.mean().unstack()
p('## 3.3 Nejistota z backtestu\n')
p('### 80. percentil chyby obcí (T = 2012 → 2020, 8 let, model s faktory), %\n')
p(p80[[t[0] for t in TRIDY]].round(1).to_markdown())
p('\nPro srovnání průměr (MAPE) – musí sedět s backtest-vysledky.md:\n')
p(mape[[t[0] for t in TRIDY]].round(2).to_markdown())

# ---------------------------------------------------------------- 2. poměr na ORP
vaz = pd.read_csv(OUT + 'obec_orp.csv', dtype=str).set_index('kod').orp_2016_2022
orp_kody = list(map(str, d.orp_kody))
idx_orp = np.array([orp_kody.index(vaz[k]) if k in vaz.index else -1 for k in kody])
rows = []
for T, roky in ((2012, range(2016, 2021)), (2016, range(2017, 2021))):
    for rok in roky:
        X = R[T].obce[rok - T]                       # [N,2,101]
        est = np.zeros((len(orp_kody), 2, 101))
        for i in range(len(kody)):
            if R[T].existuje[i] and idx_orp[i] >= 0:
                est[idx_orp[i]] += np.nan_to_num(X[i])
        act = d.orp[rok]
        kontrola = abs(est.sum() - act.sum()) / act.sum() * 100
        for j in range(len(orp_kody)):
            r = dict(T=T, rok=rok, h=rok - T, orp=orp_kody[j], kontrola_celkem_pct=kontrola)
            for g, sl in enumerate(SKUPINY):
                a, e_ = act[j][:, sl].sum(), est[j][:, sl].sum()
                r[f'ape_{SK_NAZ[g]}'] = abs(e_ - a) / a * 100
            for obl, (a0, a1, _) in UZKE.items():
                a, e_ = act[j][:, a0:a1 + 1].sum(), est[j][:, a0:a1 + 1].sum()
                r[f'ape_{obl}'] = abs(e_ - a) / a * 100
            rows.append(r)
orp = pd.DataFrame(rows)
orp.to_csv(OUT + 'nejistota_orp_predikce.csv', index=False)
p(f'\n### Poměr chyby úzké skupiny k celé skupině (ORP, predikce obcí sečtená do ORP)\n')
p(f'Kontrola: součet predikce obcí vs. součet ORP se liší max. o {orp.kontrola_celkem_pct.max():.2f} % '
  f'(rozdíl = chyba predikce celku, ne chyba vazby).\n')
pomer = {}
radky = []
for obl, (_, _, g) in UZKE.items():
    u, c = orp[f'ape_{obl}'].mean(), orp[f'ape_{SK_NAZ[g]}'].mean()
    pomer[obl] = u / c
    radky.append(dict(oblast=obl, skupina=SK_NAZ[g], chyba_uzke=round(u, 2), chyba_skupiny=round(c, 2),
                      pomer=round(u / c, 2)))
p(pd.DataFrame(radky).set_index('oblast').to_markdown())

# ---------------------------------------------------------------- 3. nejistota.csv
rows = []
for obl, (_, _, g) in UZKE.items():
    for nm, _, _ in TRIDY:
        v = p80.loc[SK_NAZ[g], nm] * pomer[obl]
        rows.append(dict(oblast=obl, velikost=nm, skupina_backtestu=SK_NAZ[g], p80_skupiny=round(p80.loc[SK_NAZ[g], nm], 2),
                         pomer_uzke=round(pomer[obl], 3), nejistota_pct=int(round(v)),
                         metoda='P80 chyby obcí (8 let) × poměr úzké skupiny na ORP'))
nej = pd.DataFrame(rows)
nej.to_csv(OUT + 'nejistota.csv', index=False)
p('\n### Výsledná nejistota (nejistota.csv), %\n')
p(nej.pivot(index='oblast', columns='velikost', values='nejistota_pct')[[t[0] for t in TRIDY]].to_markdown())

# ---------------------------------------------------------------- 4. zpětná trefa
p('\n## 7.2 Zpětná trefa (T = 2012, roky 2013–2020)\n')
T = 2012
sm = lambda u: 'růst' if u in ('rust', 'vyrazny_rust') else ('pokles' if u == 'pokles' else 'bez změny')
rows = []
for i in np.nonzero(R[T].existuje & ~np.isnan(d.obce_celkem[2020]))[0]:
    for g in (0, 2):
        Dp = {T: act_skup(T)[i, g]}            # výchozí stav = skutečnost v roce T (stejně jako D0 = 2025)
        Da = {T: act_skup(T)[i, g]}
        for rok in range(T + 1, 2021):
            Dp[rok] = pred_skup(T, rok)[i, g]
            Da[rok] = act_skup(rok)[i, g]
        n = p80.loc[SK_NAZ[g], trida(vel[i])]
        hp = S.hodnot(Dp, (T + 1, 2020), n, 5, rok0=T)
        ha = S.hodnot(Da, (T + 1, 2020), n, 5, rok0=T)
        rows.append(dict(kod=kody[i], skupina=SK_NAZ[g], trida=trida(vel[i]), pred=sm(hp['uroven']),
                         skut=sm(ha['uroven'])))
zt = pd.DataFrame(rows)
zt.to_csv(OUT + 'zpetna_trefa.csv', index=False)
for g in ('0-14', '65+'):
    x = zt[zt.skupina == g]
    p(f'**{g}:** směr doporučení sedí v **{(x.pred == x.skut).mean() * 100:.0f} %** obcí ({len(x)} obcí)\n')
    p(pd.crosstab(x.pred, x.skut, rownames=['predikce'], colnames=['skutečnost']).to_markdown())
    p('')
    p('Podle velikosti: ' + ', '.join(f'{t}: {((y.pred == y.skut).mean() * 100):.0f} %'
                                      for t, y in x.groupby('trida', sort=False)))
    p('')
x = zt
p(f'**Celkem:** směr sedí v {(x.pred == x.skut).mean() * 100:.0f} % případů (obec × skupina).')
open(OUT + 'nejistota_backtest.md', 'w').write('\n'.join(L) + '\n')
