"""Kap. 7.2 (citlivost prahů) a 7.3 (kontroly). Zapisuje overeni.md a kontrola_dojizdka.csv do OUT."""
import json, sys, math, glob
import pandas as pd
import openpyxl

sys.path.insert(0, '/home/claude/scripts')
import s4_doporuceni as S

OUT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/out/'
PRED = S.PRED
U = '/mnt/user-data/uploads/'
L = []          # řádky reportu
def p(*a):
    s = ' '.join(str(x) for x in a); print(s); L.append(s)

obce, dost, skoly, nej, meta, pred = S.nacti_vstupy(OUT)
zakl = S.spocitej(obce, dost, skoly, nej, meta, pred, s_texty=False)
KL = [o[0] for o in S.OBLASTI]
BARVA = {'vyrazny_rust': '🔴 výrazný růst', 'rust': '🟠 růst', 'pokles': '🔵 pokles', 'ok': '🟢 bez výrazné změny'}

def urovne(out):
    return pd.DataFrame({k: {o['klic']: o['uroven'] for o in v['oblasti']} for k, v in out.items()}).T

def spatne(out):
    return pd.DataFrame({k: {o['klic']: o['spatna_dostupnost'] for o in v['oblasti']} for k, v in out.items()}).T

U0, SP0 = urovne(zakl), spatne(zakl)

# ------------------------------------------------ 7.3 kontroly
p('## 7.3 Kontroly\n')
files = glob.glob(OUT + 'obce/*.json')
p(f'* Souborů ve výstupu: {len(files)} (očekáváno 401)')
chyby = []
zmeny_pred = 0
for f in files:
    s = open(f).read()
    if 'NaN' in s or 'Infinity' in s:
        chyby.append(f'NaN/Inf v {f}')
    o = json.loads(s)
    k = o['kod']
    orig = json.load(open(f'{PRED}obce/{k}.json'))
    o2 = {a: b for a, b in o.items() if a != 'doporuceni'}
    if o2 != orig or json.dumps(o2, ensure_ascii=False, separators=(',', ':')) != open(f'{PRED}obce/{k}.json').read():
        zmeny_pred += 1
    d = o['doporuceni']
    if len(d['oblasti']) != 5 or [x['klic'] for x in d['oblasti']] != KL:
        chyby.append(f'{k}: nemá 5 oblastí')
    if d['velke_mesto']:
        if not d['varovani']:
            chyby.append(f'{k}: velké město bez varování')
        if any(x['dostupnost'] is not None for x in d['oblasti']):
            chyby.append(f'{k}: velké město s dostupností')
    s25 = sum(orig['projekce']['muzi'][0][3:6]) + sum(orig['projekce']['zeny'][0][3:6])
    if abs(d['oblasti'][0]['stav_2025']['hodnota'] - round(s25, 1)) > 1e-9:
        chyby.append(f'{k}: stav_2025 MŠ nesedí')
    for x in d['oblasti']:
        od, do = {'ms': (3, 5), 'zs': (6, 10), 'pldd': (0, 18), 'pl': (19, 100), 'sen': (80, 100)}[x['klic']]
        s25 = sum(orig['projekce']['muzi'][0][od:do + 1]) + sum(orig['projekce']['zeny'][0][od:do + 1])
        if abs(x['stav_2025']['hodnota'] - round(s25, 1)) > 1e-9:
            chyby.append(f'{k}/{x["klic"]}: stav_2025 nesedí')
        if not x['texty']:
            chyby.append(f'{k}/{x["klic"]}: bez textu')
p(f'* Data predikce změněná proti originálu: {zmeny_pred} souborů (očekáváno 0; porovnáno bajt po bajtu bez pole doporuceni)')
p(f'* Každá obec má 5 oblastí, velká města mají varování a nemají dostupnost, stav_2025 = součet ročníků 2025, '
  f'žádné NaN: {"OK" if not chyby else "CHYBY: " + "; ".join(chyby[:10])}')
vm = [v for v in obce if zakl[v['kod']]['velke_mesto']]
p(f'* Velká města (> 15 000 obyv. v 2025): {", ".join(v["nazev"] for v in vm)}')

p('\n### Rozložení barev\n')
tab = U0.apply(lambda c: c.value_counts()).reindex(list(BARVA)).fillna(0).astype(int)
tab.index = [BARVA[i] for i in tab.index]
p(tab.to_markdown())
p('\n### Špatná dostupnost (VHD > 30 min), počet obcí\n')
for k in ('ms', 'zs', 'pldd', 'pl'):
    c = SP0[k]
    p(f'* {k}: hodnoceno {int(c.notna().sum())}, špatná {int((c == True).sum())}')

# dojížďka do škol
wb = openpyxl.load_workbook(U + 'd0308014-datovy_model_statistika_2022.xlsx', read_only=True)
ws = wb['ST_ekonomika']
rows = list(ws.iter_rows(values_only=True))
h = rows[0]
df = pd.DataFrame(rows[1:], columns=h)
df = df[df.Uz_jednotka == 'obec']
df = df.sort_values('Rok').dropna(subset=['MOB_DOJ_SKOLY']).groupby('Kod_text').last()
os_ = pd.read_csv(OUT + 'obce_skoly.csv', dtype={'kod': str})
os_['nazev'] = os_.kod.map({o['kod']: o['nazev'] for o in obce})
os_['doj_skoly'] = os_.kod.map(df.MOB_DOJ_SKOLY)
os_['ma_skolu'] = os_.ma_ms | os_.ma_zs
os_['doj_20'] = os_.doj_skoly >= 20
odch = os_[os_.ma_skolu != os_.doj_20].copy()
odch['popis'] = odch.apply(lambda r: 'škola v rejstříku, dojíždějících < 20' if r.ma_skolu
                           else 'bez školy v rejstříku, dojíždějících ≥ 20', axis=1)
odch.to_csv(OUT + 'kontrola_dojizdka.csv', index=False)
p(f'\n### Rejstřík vs. dojížďka do škol (MOB_DOJ_SKOLY, rok {int(df.Rok.max())})\n')
p(f'* Obce s MŠ nebo ZŠ v rejstříku: {int(os_.ma_skolu.sum())}; obce s ≥ 20 dojíždějícími do škol: {int(os_.doj_20.sum())}')
p(f'* Odchylky: {len(odch)} (z toho „škola, ale < 20 dojíždějících“: {int(odch.ma_skolu.sum())}, '
  f'„bez školy, ale ≥ 20“: {int((~odch.ma_skolu).sum())}) → kontrola_dojizdka.csv')
p('* Pozn.: MOB_DOJ_SKOLY zahrnuje dojíždějící do všech škol (i SŠ, VŠ) ze sčítání 2021, proto jde jen o hrubou kontrolu.')

# ------------------------------------------------ 7.2 citlivost prahů
p('\n## 7.2 Citlivost prahů\n')
p('Počet obcí (z 401), které změní barvu semaforu oproti základním prahům:\n')
var = {'min. počet osob × 2': {k: v * 2 for k, v in S.MIN_OSOB.items()},
       'min. počet osob × 0,5': {k: v / 2 for k, v in S.MIN_OSOB.items()}}
radky = []
for nm, mo in var.items():
    o = S.spocitej(obce, dost, skoly, nej, meta, pred, min_osob=mo, s_texty=False)
    Ux = urovne(o)
    radky.append({'varianta': nm, **{k: int((Ux[k] != U0[k]).sum()) for k in KL}})
p(pd.DataFrame(radky).set_index('varianta').to_markdown())
p('\nPočet obcí, kterým se změní značka „⚠ špatná dostupnost“ (z hodnocených):\n')
radky = []
for hr in (20, 45):
    o = S.spocitej(obce, dost, skoly, nej, meta, pred, hranice_vhd=hr, s_texty=False)
    SPx = spatne(o)
    radky.append({'hranice VHD': f'{hr} min', **{k: f'{int((SPx[k].map(repr) != SP0[k].map(repr)).sum())} / {int(SP0[k].notna().sum())}'
                                                 for k in ('ms', 'zs', 'pldd', 'pl')}})
p(pd.DataFrame(radky).set_index('hranice VHD').to_markdown())
p('\nPozn.: vrstvy mají pásma 15 / 30 / (35) / 45 / 60 min, hranice 20 min se proto chová stejně jako 15 min '
  '(obec v pásmu 15–30 min nelze rozlišit na „do 20“ a „20–30“).')

p('\n## 7.2 Zpětná trefa\n')
p('Viz nejistota_backtest.md (skript s6_nejistota_backtest.py).')

open(OUT + 'overeni.md', 'w').write('\n'.join(L) + '\n')
