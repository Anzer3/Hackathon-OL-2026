"""Vazba obec -> ORP (potřebná pro chybu úzkých skupin v predikci na ORP, kap. 3.3).

1. Z rejstříku škol (adresy PO, míst výuky, ředitelů nejsou kódované -> jen `adresa` s `uzemiDleORP`) vezme
   dvojice (obec, okres) -> ORP.
2. Chybějící obce doplní podle nejbližších sousedů (většina z 5 nejbližších bodů obcí se známým ORP).
3. Ověření: součet obyvatel obcí (OBY02E) v ORP = ORP (OBY02B) pro každý rok 2016–2025. Nesoulad -> chyba.
Výstup: OUT/obec_orp.csv
"""
import sys, json, collections
import numpy as np
import pandas as pd
import geopandas as gpd
import duckdb

OUT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/out/'
U = '/mnt/user-data/uploads/'
OKRES_KOD = {'CZ0711': 'Jeseník', 'CZ0712': 'Olomouc', 'CZ0713': 'Prostějov', 'CZ0714': 'Přerov', 'CZ0715': 'Šumperk'}

g = gpd.read_file(OUT + 'obce_body.geojson')
g['kod'] = g.kod.astype(str)
key = {(r.nazev, r.okres): r.kod for r in g.itertuples()}

r = json.load(open(U + '51cacede-RSSZ-Olomoucky-kraj.jsonld'))
hlasy = collections.defaultdict(collections.Counter)


def add(a, okres_nazev):
    if not a or not a.get('uzemiDleORP') or not a.get('obec'):
        return
    k = key.get((a['obec'], okres_nazev))
    orp = a['uzemiDleORP']
    if k and orp.startswith('CZ071'):
        hlasy[k]['71' + orp[-2:]] += 1          # CZ07107 -> 7107


for po in r['list']:
    a = po.get('adresa') or {}
    add(a, OKRES_KOD.get(a.get('okres')))
    for s in po['skolyAZarizeni']:
        for m in s.get('mistaVyuky', []):
            a = m.get('adresa') or {}
            add(a, a.get('okres'))

orp = {k: c.most_common(1)[0][0] for k, c in hlasy.items()}
print('ORP z rejstříku:', len(orp), 'obcí')

b = g.set_index('kod').to_crs(5514).geometry.representative_point()
zname = [k for k in g.kod if k in orp]
for k in g.kod:
    if k in orp:
        continue
    d = b.loc[zname].distance(b.loc[k]).nsmallest(5)
    orp[k] = collections.Counter(orp[z] for z in d.index).most_common(1)[0][0]
zdroj = {k: ('rejstřík' if k in zname else 'sousedé') for k in g.kod}

# ověření součtů
e = duckdb.sql("select uz, rok, h from '/home/claude/data/csu/oby02e_ok.parquet' where pohl=0 and sk='VEKC'").df()
o = duckdb.sql("select uz, rok, sum(h) h from '/home/claude/data/csu/oby02b_ok.parquet' where uz between '7101' and '7113' group by 1,2").df()


def kontrola():
    e['orp'] = e.uz.map(orp)
    s = e.dropna(subset=['orp']).groupby(['orp', 'rok']).h.sum()
    m = o.rename(columns={'uz': 'orp'}).set_index(['orp', 'rok']).h
    rozdil = (s - m).dropna()
    return rozdil[rozdil.index.get_level_values(1) >= 2016]


# oprava: celočíselná úloha – každá obec do jednoho ORP svého okresu tak, aby součty obyvatel
# za každý ORP a rok 2017–2025 přesně seděly. Změna proti odhadu (rejstřík / sousedé) je penalizovaná.
from scipy.optimize import milp, LinearConstraint, Bounds
ORP_OKRES = {'7101': 'Přerov', '7102': 'Jeseník', '7103': 'Prostějov', '7104': 'Přerov', '7105': 'Olomouc',
             '7106': 'Šumperk', '7107': 'Olomouc', '7108': 'Prostějov', '7109': 'Přerov', '7110': 'Olomouc',
             '7111': 'Šumperk', '7112': 'Olomouc', '7113': 'Šumperk'}
okres_obce = dict(zip(g.kod, g.okres))
# vojenský újezd / obec Libavá (503941) – v predikci není, ale do 2015 měla obyvatele -> musí být ve vazbě
KODY = list(g.kod) + ['503941']
okres_obce['503941'] = 'Olomouc'
orp.setdefault('503941', '7107'); zdroj.setdefault('503941', 'sousedé')
cil = o.rename(columns={'uz': 'orp'}).set_index(['orp', 'rok']).h


def res_milp(roky, prior, zdroj_prior):
    """každá obec do jednoho ORP svého okresu, součty obyvatel za ORP a roky přesně = OBY02B"""
    pop = e[e.rok.isin(roky)].pivot(index='uz', columns='rok', values='h').reindex(columns=roky).fillna(0)
    var = [(k, q) for k in KODY for q in ORP_OKRES if ORP_OKRES[q] == okres_obce[k]]
    c = np.array([0 if prior[k] == q else (10 if zdroj_prior[k] == 'rejstřík' else 1) for k, q in var], float)
    A, lo, hi = [], [], []
    for k in KODY:
        A.append([1.0 if v[0] == k else 0.0 for v in var]); lo.append(1); hi.append(1)
    for q in ORP_OKRES:
        for rk in roky:
            A.append([pop.loc[v[0], rk] if (v[1] == q and v[0] in pop.index) else 0.0 for v in var])
            lo.append(cil[(q, rk)] - 0.5); hi.append(cil[(q, rk)] + 0.5)
    r = milp(c, constraints=LinearConstraint(np.array(A), lo, hi), integrality=np.ones(len(var)),
             bounds=Bounds(0, 1))
    assert r.status == 0, r.message
    return {k: q for (k, q), xv in zip(var, r.x) if xv > 0.5}


# vazba platná od 2023 (data 2023–2025) a 2016–2022 (před 2016 se obce dělily, součty ORP nejdou sladit)
orp_new = res_milp([2023, 2024, 2025], orp, zdroj)
orp_old = res_milp(list(range(2016, 2023)), orp_new, {k: 'rejstřík' for k in orp_new})
for k in g.kod:
    if orp_new[k] != orp[k]:
        zdroj[k] = zdroj[k] + ' → opraveno součtem'
orp = orp_new


def kontrola_obdobi(mapa, roky):
    x = e[e.rok.isin(roky)].copy(); x['orp'] = x.uz.map(mapa)
    s = x.dropna(subset=['orp']).groupby(['orp', 'rok']).h.sum()
    return (s - cil[cil.index.get_level_values(1).isin(roky)]).abs().max()


print('nesoulad 2023–2025:', kontrola_obdobi(orp_new, [2023, 2024, 2025]),
      '| 2016–2022:', kontrola_obdobi(orp_old, list(range(2016, 2023))))
zmena = [k for k in g.kod if orp_new[k] != orp_old[k]]
print('obce, které změnily ORP mezi 2022 a 2023:', [(dict(zip(g.kod, g.nazev))[k], orp_old[k], orp_new[k]) for k in zmena])
pd.DataFrame({'kod': g.kod, 'nazev': g.nazev, 'orp_od_2023': g.kod.map(orp_new), 'orp_2016_2022': g.kod.map(orp_old),
              'zdroj': g.kod.map(zdroj)}).to_csv(OUT + 'obec_orp.csv', index=False)
print(pd.Series(zdroj).value_counts())
raise SystemExit
roz = kontrola()
print('nesoulad po opravě (max |rozdíl|):', roz.abs().max())
if roz.abs().max() >= 0.5:
    print(roz[roz.abs() >= 0.5])
pd.DataFrame({'kod': list(orp), 'orp': list(orp.values()), 'zdroj': [zdroj[k] for k in orp]}).to_csv(
    OUT + 'obec_orp.csv', index=False)
print(pd.Series(zdroj).value_counts())
