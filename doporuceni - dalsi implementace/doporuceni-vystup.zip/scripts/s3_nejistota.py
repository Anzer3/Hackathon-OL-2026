"""Kap. 3.3 – nejistota. Záložní varianta podle plánu:
kód backtestu ani data backtestu (OBY02E/OBY02B) nejsou k dispozici, proto se 80. percentil ani poměr
úzkých skupin nepočítá. Použije se průměrná chyba z backtest-vysledky.md (T = 2012, kontrola 2020,
horizont 8 let, model s faktory), zaokrouhlená na celá %, a v textu se uvede „nejistota může být vyšší“.

Přiřazení oblastí ke skupinám backtestu:
  ms (3–5), zs (6–10), pldd (0–18) -> 0–14
  pl (19+)                         -> 15–64
  sen (80+)                        -> 65+
"""
import sys
import pandas as pd

OUT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/out/'

# backtest-vysledky.md, tabulka „Výchozí rok 2012, kontrola 2020 (horizont 8 let)“, sloupec „s faktory“
MAPE_8 = {
    '0-14':  {'< 500': 18.83, '500–1 999': 11.80, '2 000+': 6.67},
    '15-64': {'< 500': 7.34,  '500–1 999': 4.67,  '2 000+': 3.12},
    '65+':   {'< 500': 11.46, '500–1 999': 7.33,  '2 000+': 4.13},
}
SKUPINA = {'ms': '0-14', 'zs': '0-14', 'pldd': '0-14', 'pl': '15-64', 'sen': '65+'}

rows = []
for obl, sk in SKUPINA.items():
    for vel, v in MAPE_8[sk].items():
        rows.append(dict(oblast=obl, velikost=vel, skupina_backtestu=sk, mape_8let=v,
                         nejistota_pct=round(v), metoda='průměrná chyba backtestu (záloha kap. 3.3)'))
df = pd.DataFrame(rows)
df.to_csv(OUT + 'nejistota.csv', index=False)
print(df.pivot(index='oblast', columns='velikost', values='nejistota_pct'))
