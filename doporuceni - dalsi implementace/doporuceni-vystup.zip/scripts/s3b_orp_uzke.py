"""Kap. 3.3 bod 2 – chyba úzkých skupin na ORP (rozpočet IPF ze 3 skupin + profil okresu).

IPF podle navrh-predikcniho-modelu.md kap. 2.1 (stejně jako test ročníků v backtest.py):
ORP v okrese = jednotky, omezení (a) součty 3 skupin ORP po pohlaví, (b) součet ORP za ročník = okres.
Výstup: OUT/nejistota_orp.csv (chyba odhadu stavu v cílovém věku, po ORP a roce) + souhrn.
"""
import sys
import numpy as np
import pandas as pd
import duckdb

OUT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/out/'
P = '/home/claude/data/csu/oby02b_ok.parquet'
OKRESY = ['CZ0711', 'CZ0712', 'CZ0713', 'CZ0714', 'CZ0715']
ORP_OKRES = {'7101': 'CZ0714', '7102': 'CZ0711', '7103': 'CZ0713', '7104': 'CZ0714', '7105': 'CZ0712',
             '7106': 'CZ0715', '7107': 'CZ0712', '7108': 'CZ0713', '7109': 'CZ0714', '7110': 'CZ0712',
             '7111': 'CZ0715', '7112': 'CZ0712', '7113': 'CZ0715'}
NAZVY = {'7101': 'Hranice', '7102': 'Jeseník', '7103': 'Konice', '7104': 'Lipník n. B.', '7105': 'Litovel',
         '7106': 'Mohelnice', '7107': 'Olomouc', '7108': 'Prostějov', '7109': 'Přerov', '7110': 'Šternberk',
         '7111': 'Šumperk', '7112': 'Uničov', '7113': 'Zábřeh'}
SKUPINY = [slice(0, 15), slice(15, 65), slice(65, 101)]
UZKE = {'ms 3–5': (3, 5, 0), 'zs 6–10': (6, 10, 0), 'pldd 0–18': (0, 18, None),
        'pl 19+': (19, 100, None), 'sen 80+': (80, 100, 2)}

df = duckdb.sql(f"select * from '{P}'").df()
df['vek'] = df.vek_txt.str.extract(r'^(\d+)').astype(int)


def pole(uz, rok):
    x = df[(df.uz == uz) & (df.rok == rok)]
    a = np.zeros((2, 101))
    a[x.pohl.values - 1, x.vek.values] = x.h.values
    return a


def ipf(sk, okres, it=500, tol=1e-9):
    """sk [n,2,3] součty skupin jednotek, okres [2,101] -> [n,2,101]"""
    n = sk.shape[0]
    X = np.zeros((n, 2, 101))
    for g, sl in enumerate(SKUPINY):           # start: profil okresu oříznutý na skupinu
        prof = okres[:, sl] / np.maximum(okres[:, sl].sum(1, keepdims=True), 1e-12)
        X[:, :, sl] = sk[:, :, g:g + 1] * prof[None]
    for _ in range(it):
        s = X.sum(0)                            # (b) součet jednotek za ročník = okres
        X *= np.where(s > 0, okres / np.maximum(s, 1e-12), 0)[None]
        for g, sl in enumerate(SKUPINY):        # (a) součty skupin = skutečnost
            t = X[:, :, sl].sum(2, keepdims=True)
            X[:, :, sl] *= np.where(t > 0, sk[:, :, g:g + 1] / np.maximum(t, 1e-12), 0)
        if np.abs(X.sum(0) - okres).max() < tol:
            break
    return X


orp_kody = sorted(ORP_OKRES)
rows = []
souhrn = {}
for rok in range(2007, 2026):
    act = np.stack([pole(k, rok) for k in orp_kody])
    est = np.zeros_like(act)
    for ok in OKRESY:
        idx = [i for i, k in enumerate(orp_kody) if ORP_OKRES[k] == ok]
        sk = np.stack([act[idx][:, :, sl].sum(2) for sl in SKUPINY], 2)
        est[idx] = ipf(sk, pole(ok, rok))
    err = np.abs(est - act)
    souhrn[rok] = err.sum() / 2 / act.sum() * 100
    for i, k in enumerate(orp_kody):
        r = dict(rok=rok, orp=NAZVY[k], obyv=act[i].sum(),
                 spatny_rocnik_pct=err[i].sum() / 2 / act[i].sum() * 100,
                 chyba_15_39_pct=err[i][:, 15:40].sum() / act[i][:, 15:40].sum() * 100)
        for nm, (a, b, _) in UZKE.items():
            A = act[i][:, a:b + 1].sum(); E = est[i][:, a:b + 1].sum()
            r[f'ape_{nm}'] = abs(E - A) / A * 100
        rows.append(r)

res = pd.DataFrame(rows)
res.to_csv(OUT + 'nejistota_orp.csv', index=False)
print('kontrola proti backtest.md: ve špatném ročníku 2025 = %.1f %%, 2016 = %.1f %%' % (souhrn[2025], souhrn[2016]))
print(res[res.rok == 2025][['orp', 'obyv', 'spatny_rocnik_pct', 'chyba_15_39_pct']].round(1).to_string(index=False))
c = [c for c in res.columns if c.startswith('ape_')]
print('\nChyba odhadu stavu v úzké skupině (APE %, 13 ORP × roky 2007–2025, Jeseník = okres vynechán):')
x = res[res.orp != 'Jeseník']
print(x[c].describe(percentiles=[.5, .8]).round(2).to_string())
