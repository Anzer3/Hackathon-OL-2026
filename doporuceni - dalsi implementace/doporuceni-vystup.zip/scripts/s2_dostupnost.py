"""Kap. 1.3–1.5: dostupnost obcí, kontrola rejstříku proti vrstvám, nejbližší obec s MŠ/ZŠ.

Výstupy (do OUT):
  dostupnost.csv – kod, nazev, okres, pro každou vrstvu {ms,zs,pldd,pl} sloupce <v>_auto_min, <v>_vhd_min, <v>_pesi_m
                   (horní mez nejmenšího pásma s bodem obce; prázdné = mimo všechny zóny = nad 60 min / nad 2 km),
                   <v>_vrstva_v_obci (pěší zóna 0–100 m zasahuje do polygonu obce),
                   ma_ms, ma_zs (rejstřík), rozpor_ms, rozpor_zs, nejblizsi_obec_ms, nejblizsi_obec_zs
  rozpory.csv    – obce, kde rejstřík a vrstva nesouhlasí
"""
import sys
import pandas as pd
import geopandas as gpd

U = '/mnt/user-data/uploads/'
OUT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/out/'

VRSTVY = {
    'ms': U + 'af3e12c5-Dostupnost_mate_sk_ch__kol_8986982943234190429.geojson',
    'zs': U + '29b0c08c-Dostupnost_z_kladn_ch__kol_-8064531570351284089.geojson',
    'pldd': U + '097b648e-Dostupnost_d_tsk_ho_l_ka_e_-2586496660885284528.geojson',
    'pl': U + '25bcfe96-Dostupnost_praktick_ho_l_ka_e_pro_dosp_l__-2628092891664027414.geojson',
}
REZIM = {'IAD': 'auto_min', 'VHD': 'vhd_min', 'PESI': 'pesi_m'}

obce = gpd.read_file(OUT + 'obce_body.geojson', dtype={'kod': str})
obce['kod'] = obce.kod.astype(str)
body = gpd.GeoDataFrame(obce[['kod']], geometry=gpd.points_from_xy(obce.bod_lon, obce.bod_lat), crs=4326)
poly = obce[['kod', 'geometry']]
skoly = pd.read_csv(OUT + 'obce_skoly.csv', dtype={'kod': str})

res = obce[['kod', 'nazev', 'okres', 'velke_mesto']].copy()
for v, f in VRSTVY.items():
    z = gpd.read_file(f)[['KAT', 'ToBreak', 'geometry']]
    z['geometry'] = z.geometry.make_valid()
    j = gpd.sjoin(body, z, predicate='within')
    for kat, col in REZIM.items():
        m = j[j.KAT == kat].groupby('kod').ToBreak.min()
        res[f'{v}_{col}'] = res.kod.map(m).astype('Int64')
    z100 = z[(z.KAT == 'PESI') & (z.ToBreak == 100)]
    jj = gpd.sjoin(poly, z100, predicate='intersects')
    res[f'{v}_vrstva_v_obci'] = res.kod.isin(set(jj.kod))
    print(v, 'auto do 15 min:', int((res[f'{v}_auto_min'] <= 15).sum()),
          '| VHD nad 30 min (vč. mimo zóny):', int((res[f'{v}_vhd_min'].fillna(999) > 30).sum()),
          '| VHD mimo zóny:', int(res[f'{v}_vhd_min'].isna().sum()),
          '| pěší zóna 0–100 m v obci:', int(res[f'{v}_vrstva_v_obci'].sum()))

res = res.merge(skoly, on='kod')
res['rozpor_ms'] = res.ma_ms != res.ms_vrstva_v_obci
res['rozpor_zs'] = res.ma_zs != res.zs_vrstva_v_obci

# 1.5 nejbližší obec s MŠ / ZŠ podle vzdálenosti bodů obcí (S-JTSK, m)
b = body.to_crs(5514).set_index('kod').geometry
nazvy = dict(zip(obce.kod, obce.nazev))
for d, col in (('ms', 'ma_ms'), ('zs', 'ma_zs')):
    s_kody = res[res[col]].kod.tolist()
    s_body = b.loc[s_kody]
    out = {}
    for k in res[~res[col]].kod:
        dist = s_body.distance(b.loc[k])
        out[k] = nazvy[dist.idxmin()]
    res[f'nejblizsi_obec_{d}'] = res.kod.map(out)

res.to_csv(OUT + 'dostupnost.csv', index=False)

rows = []
for d, col in (('ms', 'ma_ms'), ('zs', 'ma_zs')):
    x = res[res[f'rozpor_{d}']]
    for _, r in x.iterrows():
        rows.append(dict(kod=r.kod, nazev=r.nazev, okres=r.okres, oblast=d.upper(),
                         rejstrik_ma=bool(r[col]), vrstva_ma=bool(r[f'{d}_vrstva_v_obci']),
                         popis=('rejstřík ano, vrstva ne' if r[col] else 'rejstřík ne, vrstva ano')))
pd.DataFrame(rows).to_csv(OUT + 'rozpory.csv', index=False)
print('rozpory MŠ:', int(res.rozpor_ms.sum()), 'ZŠ:', int(res.rozpor_zs.sum()))
