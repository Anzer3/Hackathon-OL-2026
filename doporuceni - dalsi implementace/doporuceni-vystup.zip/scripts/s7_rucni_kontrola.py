"""Seznam obcí k ruční kontrole -> OUT/rucni_kontrola.csv
Důvody: rozpor rejstřík × vrstva (1.4), vyřazená škola v obci (1.2: podle názvu / mimo kraj).
Sloupec `dopad` říká, co se kvůli tomu na kartě obce zobrazí."""
import sys, json
import pandas as pd
OUT = sys.argv[1]
U = '/mnt/user-data/uploads/'
obce = json.load(open('/home/claude/data/zip/data/obce.json'))
naz = {o['kod']: o['nazev'] for o in obce}; okr = {o['kod']: o['okres'] for o in obce}
key = {(o['nazev'], o['okres']): o['kod'] for o in obce}
d = pd.read_csv(OUT + 'dostupnost.csv', dtype={'kod': str}).set_index('kod')
sk = pd.read_csv(OUT + 'skoly.csv', dtype={'kod': str})
v = pd.read_csv(OUT + 'skoly_vyrazene.csv', dtype={'kod': str})
rows = []
for r in pd.read_csv(OUT + 'rozpory.csv', dtype={'kod': str}).itertuples():
    rows.append(dict(kod=r.kod, obec=r.nazev, okres=r.okres, oblast={'MS': 'MŠ', 'ZS': 'ZŠ'}[r.oblast], duvod='rozpor rejstřík × vrstva dostupnosti',
                     detail=r.popis, dopad=('karta: škola v obci je, dostupnost se nezobrazuje' if r.rejstrik_ma
                                            else 'karta: obec nemá vlastní školu, dostupnost se nezobrazuje'),
                     co_overit='je v obci opravdu MŠ/ZŠ? (mapa, web obce)'))
for r in v.itertuples():
    k = r.kod if isinstance(r.kod, str) else None
    if k is None:   # místo mimo kraj – najít obec podle názvu PO (Ústí, okres Přerov)
        if 'Ústí' in r.nazev_po:
            k = key[('Ústí', 'Přerov')]
        else:
            k = key.get((r.obec, r.okres))
    if k is None:
        continue
    druh = r.druh
    dn = {'MS': 'MŠ', 'ZS': 'ZŠ'}[druh]
    ma = bool(d.loc[k, f'ma_{druh.lower()}'])
    jine = sk[(sk.kod == k) & (sk.druh == druh)].nazev_po.nunique()
    dopad = (f'obec má i jinou {dn} ({jine}) – karta se nemění' if ma
             else f'obec nemá jinou {dn} → karta píše „Obec nemá vlastní {dn}“')
    rows.append(dict(kod=k, obec=naz[k], okres=okr[k], oblast=dn,
                     duvod='vyřazená škola: ' + r.duvod, detail=r.nazev_po, dopad=dopad,
                     co_overit=('je škola běžně přístupná všem dětem? pokud ano, vrátit' if ma is False
                                else 'jen informace')))
df = pd.DataFrame(rows).drop_duplicates()
df['priorita'] = (df.dopad.str.contains('nemá') | df.duvod.str.startswith('rozpor')).map({True: 'A – ověřit (ovlivňuje kartu)', False: 'B – jen informace'})
df = df.sort_values(['priorita', 'obec', 'oblast'])
df.to_csv(OUT + 'rucni_kontrola.csv', index=False)
print(df[['priorita', 'obec', 'oblast', 'duvod', 'dopad']].to_string(index=False))
