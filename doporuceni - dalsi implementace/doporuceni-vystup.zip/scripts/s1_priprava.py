"""Kap. 1.1 a 1.2: příprava obcí a rejstříku škol.

Výstupy (do OUT):
  obce_body.geojson      – 401 obcí, polygon opravený make_valid, bod = representative_point
  skoly.csv              – místa výuky MŠ/ZŠ napojená na obec (po vyřazení)
  skoly_vyrazene.csv     – vyřazené školy / místa a důvod
  skoly_nenapojene.csv   – místa, která se nepodařilo napojit (kontrola)
  obce_skoly.csv         – kod, ma_ms, ma_zs
"""
import json, sys, re, unicodedata
import pandas as pd
import geopandas as gpd

U = '/mnt/user-data/uploads/'
PRED = '/home/claude/data/zip/data/'
OUT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/out/'

# ---------------- 1.1 Obce ----------------
g = gpd.read_file(U + 'ac5b5402-obce-olomoucky-kraj.geojson')
n_invalid = int((~g.is_valid).sum())
g['geometry'] = g.geometry.make_valid()
pred = json.load(open(PRED + 'obce.json'))
pred_kody = {p['kod'] for p in pred}
vyrazene_obce = g[~g.kod.isin(pred_kody)][['kod', 'nazev', 'okres']]
g = g[g.kod.isin(pred_kody)].copy()
assert len(g) == 401
pt = g.geometry.representative_point()
g['bod_lon'] = pt.x.round(6)
g['bod_lat'] = pt.y.round(6)
assert g.geometry.contains(pt).all()

# velikost obce 2025 podle predikce
pop = {}
for k in g.kod:
    o = json.load(open(f'{PRED}obce/{k}.json'))
    pop[k] = sum(o['projekce']['muzi'][0]) + sum(o['projekce']['zeny'][0])
g['obyv_2025'] = g.kod.map(pop).round(1)
g['velke_mesto'] = g.obyv_2025 > 15000
g[['kod', 'nazev', 'okres', 'obyv_2025', 'velke_mesto', 'bod_lon', 'bod_lat', 'geometry']].to_file(
    OUT + 'obce_body.geojson', driver='GeoJSON')
print(f'1.1 obce: {len(g)}, neplatných polygonů opraveno: {n_invalid}, vyřazeno: {vyrazene_obce.to_dict("records")}')
print('    velká města:', g[g.velke_mesto][['nazev', 'obyv_2025']].values.tolist())

# ---------------- 1.2 Rejstřík škol ----------------
r = json.load(open(U + '51cacede-RSSZ-Olomoucky-kraj.jsonld'))
DATUM_REJSTRIKU = r['datumVystupu']

KLICOVA_SLOVA = ['speciální', 'logopedick', 'pro sluchově', 'pro zrakově', 'pro tělesně',
                 'diagnostický ústav', 'dětský domov', 'při nemocnici', 'při zdravotnickém']
KLICOVA_SLOVA_MS = ['lesní']  # lesní MŠ: vyřazuje se jen MŠ, ZŠ téže PO zůstává
MIMO_KRAJ = {'Valašské Meziříčí', 'Ústí'}  # okres Vsetín

# ruční opravy obce místa výuky (zjištěno z nenapojených míst při 1. běhu)
OPRAVY = {
    'obec Olomouc': 'Olomouc',
    'obec Olomouc (k.ú. Řepčín)': 'Olomouc',
    'obec Horka nad Moravou': 'Horka nad Moravou',
    'Dolany-Véska 64': 'Dolany',
}

obce_key = {(row.nazev, row.okres): row.kod for row in g.itertuples()}


def norm_obec(s):
    s = (s or '').strip()
    return OPRAVY.get(s, s)


rows = []
for po in r['list']:
    po_nazev = po['uplnyNazev']
    for s in po['skolyAZarizeni']:
        if s['druh'] not in ('A00', 'B00'):
            continue
        kap = None
        if s.get('kapacity'):
            kap = s['kapacity'][0].get('nejvyssiPovolenyPocet')
        for m in s['mistaVyuky']:
            a = m.get('adresa') or {}
            rows.append(dict(druh='MS' if s['druh'] == 'A00' else 'ZS', redIzo=po['redIzo'], izo=s['izo'],
                             IDmista=m.get('IDmista'), typ_mista=m.get('typ'), nazev_po=po_nazev,
                             obec_rejstrik=a.get('obec'), cast_obce=a.get('castObce'), ulice=a.get('ulice'),
                             okres=a.get('okres'), kapacita_skoly=kap))
mv = pd.DataFrame(rows)
print(f'1.2 míst výuky: MŠ {sum(mv.druh=="MS")}, ZŠ {sum(mv.druh=="ZS")}')

mv['obec'] = mv.obec_rejstrik.map(norm_obec)
mv['kod'] = [obce_key.get((o, ok)) for o, ok in zip(mv.obec, mv.okres)]

vyr = []
# mimo kraj
mask_mimo = mv.obec.isin(MIMO_KRAJ) & mv.kod.isna()
for _, x in mv[mask_mimo].iterrows():
    vyr.append({**x.to_dict(), 'duvod': 'místo mimo kraj'})
mv = mv[~mask_mimo]

nenap = mv[mv.kod.isna()]
nenap.to_csv(OUT + 'skoly_nenapojene.csv', index=False)
mv = mv[mv.kod.notna()]


def duvod_nazev(n, druh):
    nl = n.lower()
    for k in KLICOVA_SLOVA + (KLICOVA_SLOVA_MS if druh == 'MS' else []):
        if k in nl:
            return 'název PO obsahuje „' + k + '“'
    return None


mv['opraveno'] = mv.obec != mv.obec_rejstrik
print('    ručně opravená obec u míst:', mv[mv.opraveno][['obec_rejstrik', 'obec']].values.tolist())
mv['duvod'] = [duvod_nazev(n, d) for n, d in zip(mv.nazev_po, mv.druh)]
for _, x in mv[mv.duvod.notna()].iterrows():
    vyr.append(x.to_dict())
mv = mv[mv.duvod.isna()].drop(columns='duvod')

vyr = pd.DataFrame(vyr)
vyr.to_csv(OUT + 'skoly_vyrazene.csv', index=False)
mv['nazev_obce'] = mv.kod.map(dict(zip(g.kod, g.nazev)))
mv = mv[['kod', 'nazev_obce', 'okres', 'druh', 'nazev_po', 'izo', 'IDmista', 'typ_mista', 'obec_rejstrik',
         'cast_obce', 'ulice', 'kapacita_skoly']]
mv.to_csv(OUT + 'skoly.csv', index=False)

os_ = pd.DataFrame({'kod': g.kod.values})
os_['ma_ms'] = os_.kod.isin(mv[mv.druh == 'MS'].kod)
os_['ma_zs'] = os_.kod.isin(mv[mv.druh == 'ZS'].kod)
os_.to_csv(OUT + 'obce_skoly.csv', index=False)

print(f'    napojeno MŠ {sum(mv.druh=="MS")} + vyř. {sum(vyr.druh=="MS") if len(vyr) else 0}, '
      f'ZŠ {sum(mv.druh=="ZS")} + vyř. {sum(vyr.druh=="ZS") if len(vyr) else 0}; nenapojeno {len(nenap)}')
print(f'    vyřazené PO (unikátní): {vyr[vyr.duvod!="místo mimo kraj"].nazev_po.nunique()}')
print(f'    obcí s MŠ {os_.ma_ms.sum()}, se ZŠ {os_.ma_zs.sum()}; rejstřík k {DATUM_REJSTRIKU}')
json.dump({'datum_rejstriku': DATUM_REJSTRIKU, 'neplatne_polygony': n_invalid}, open(OUT + 'meta_1.json', 'w'))
