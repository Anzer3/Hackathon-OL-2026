"""Kap. 3–6: hotová predikce -> D(t) -> změny -> semafor -> dostupnost -> texty -> pole `doporuceni`.

Použití:
  python3 s4_doporuceni.py OUT            # zapíše OUT/obce/<kód>.json (predikce beze změny + doporuceni)
Funkce `spocitej(...)` se volá i z ověření (s5_overeni.py) s jinými prahy.
"""
import json, math, sys, os, copy
import pandas as pd

PRED = '/home/claude/data/zip/data/'
ROK0 = 2025
HORIZONT_OVERENY = 8          # backtest ověřil 8 let -> dál „orientačně“
VELKE_MESTO = 15000

OBLASTI = [
    # klic, nazev, vek_text, vek_od, vek_do (vč.), obdobi, min_osob
    ('ms', 'Mateřská škola', '3–5', 3, 5, (2026, 2031), 5),
    ('zs', 'ZŠ – 1. stupeň', '6–10', 6, 10, (2026, 2033), 5),
    ('pldd', 'Dětský lékař', '0–18', 0, 18, (2026, 2037), 20),
    ('pl', 'Praktický lékař', '19+', 19, 100, (2026, 2040), 50),
    ('sen', 'Péče o seniory', '80+', 80, 100, (2026, 2055), 5),
]
MIN_OSOB = {o[0]: o[6] for o in OBLASTI}
MAX_VYPIS_ZARIZENI = 3      # víc zařízení -> jedna souhrnná věta (seznam zůstává v zarizeni_v_obci)
HRANICE_VHD = 30              # špatná dostupnost = VHD dál než 30 min

ZARIZENI = {'ms': 'MŠ', 'zs': 'ZŠ', 'pldd': 'dětský lékař', 'pl': 'praktický lékař pro dospělé'}
VRSTVA = {'ms': 'vrstva dostupnosti MŠ (stav k roku 2022)', 'zs': 'vrstva dostupnosti ZŠ (stav k roku 2022)',
          'pldd': 'vrstva dostupnosti dětského lékaře (stav k roku 2022)',
          'pl': 'vrstva dostupnosti praktického lékaře (stav k roku 2022)'}
# hranice pásem ve vrstvách (pro text „30–45 min“)
VHD_PASMA = {'ms': [15, 30, 45, 60], 'zs': [15, 30, 45, 60], 'pldd': [15, 30, 35, 45, 60], 'pl': [15, 30, 35, 45, 60]}
PESI_PASMA = [100, 200, 300, 400, 500, 600, 700, 800, 900, 1000, 1500, 2000]

VAROVANI = ('Doporučení je spočítané za celé město. Neodráží rozdíly mezi městskými částmi, '
            'proto je jen orientační.')


# ---------------------------------------------------------------- pomocné
def zaokr_osoby(x):
    """3.4: pod 100 na celá čísla, nad 100 na desítky."""
    if x < 100:
        return str(int(round(x)))
    v = int(round(x / 10.0) * 10)
    return f'{v:,}'.replace(',', ' ')


def pct(x):
    return f'{int(round(abs(x)))}'


def velikost(n):
    return '< 500' if n < 500 else ('500–1 999' if n < 2000 else '2 000+')


def pasmo_vhd(v, klic):
    if v is None:
        return 'nad 60 min'
    p = VHD_PASMA[klic]
    i = p.index(v)
    return f'do {v} min' if i == 0 else f'{p[i-1]}–{v} min'


def pasmo_pesi(v):
    if v is None:
        return 'dál než 2 km'
    def f(m):
        return f'{m} m' if m < 1000 else (f'{m/1000:g} km'.replace('.', ','))
    i = PESI_PASMA.index(v)
    if i == 0:
        return f'do {f(v)}'
    a = PESI_PASMA[i-1]
    if a >= 1000:
        return f'{a/1000:g}–{v/1000:g} km'.replace('.', ',')
    if v < 1000:
        return f'{a}–{v} m'
    return f'{f(a)}–{f(v)}'


def nint(x):
    """pandas Int64 / NaN -> int nebo None"""
    if x is None or (isinstance(x, float) and math.isnan(x)) or pd.isna(x):
        return None
    return int(x)


# ---------------------------------------------------------------- vstupy
def nacti_vstupy(OUT):
    obce = json.load(open(PRED + 'obce.json'))
    dost = pd.read_csv(OUT + 'dostupnost.csv', dtype={'kod': str}).set_index('kod')
    skoly = pd.read_csv(OUT + 'skoly.csv', dtype={'kod': str, 'izo': str})
    nej = pd.read_csv(OUT + 'nejistota.csv')
    nej = {(r.oblast, r.velikost): int(r.nejistota_pct) for r in nej.itertuples()}
    meta = json.load(open(OUT + 'meta_1.json'))
    pred = {o['kod']: json.load(open(f'{PRED}obce/{o["kod"]}.json')) for o in obce}
    return obce, dost, skoly, nej, meta, pred


def rada(o, od, do):
    """D(t) pro všechny roky projekce (muži + ženy, věky od..do vč.)"""
    p = o['projekce']
    return {r: sum(p['muzi'][i][od:do + 1]) + sum(p['zeny'][i][od:do + 1]) for i, r in enumerate(p['roky'])}


# ---------------------------------------------------------------- jádro
def hodnot(D, obdobi, n, min_osob, rok0=ROK0):
    """Vrátí slovník s D0, max, min, změnami a úrovní semaforu (4.1)."""
    roky = list(range(obdobi[0], obdobi[1] + 1))
    D0 = D[rok0]
    hod = [D[r] for r in roky]
    imax = max(range(len(roky)), key=lambda i: hod[i])   # první výskyt maxima
    imin = min(range(len(roky)), key=lambda i: hod[i])
    t_max, Dmax, t_min, Dmin = roky[imax], hod[imax], roky[imin], hod[imin]
    Dk = hod[-1]
    r = dict(roky=roky, hod=hod, D0=D0, t_max=t_max, Dmax=Dmax, t_min=t_min, Dmin=Dmin, t_konec=roky[-1], Dkonec=Dk)
    if D0 <= 0:
        r.update(p_max=None, p_min=None, p_konec=None, uroven='ok', nula=True, vlna=None,
                 rust=False, pokles=False, duvod_ok=None)
        return r
    p_max = (Dmax - D0) / D0 * 100
    p_min = (Dmin - D0) / D0 * 100
    p_k = (Dk - D0) / D0 * 100
    rust = p_max > n and (Dmax - D0) >= min_osob
    rust2 = p_max > 2 * n and (Dmax - D0) >= min_osob
    pokles = (-p_min) > n and (D0 - Dmin) >= min_osob
    uroven = 'vyrazny_rust' if rust2 else ('rust' if rust else ('pokles' if pokles else 'ok'))
    # vlna: po špičce výrazný pokles (měřeno od špičky, stejné prahy)
    vlna = None
    if rust and imax < len(roky) - 1:
        po = hod[imax + 1:]
        j = min(range(len(po)), key=lambda i: po[i])
        Dpo, tpo = po[j], roky[imax + 1 + j]
        if (Dmax - Dpo) / Dmax * 100 > n and (Dmax - Dpo) >= min_osob:
            vlna = dict(rok=tpo, hodnota=Dpo)
    duvod_ok = None
    if uroven == 'ok':
        vetsi = max(abs(p_max), abs(p_min))
        zmena_os = max(abs(Dmax - D0), abs(D0 - Dmin))
        duvod_ok = 'nejistota' if vetsi <= n else 'min_osob'
        r.update(ok_pct=vetsi, ok_os=zmena_os)
    r.update(p_max=p_max, p_min=p_min, p_konec=p_k, uroven=uroven, nula=False, vlna=vlna,
             rust=rust, pokles=pokles, duvod_ok=duvod_ok)
    return r


def orient(rok):
    return rok > ROK0 + HORIZONT_OVERENY


def zavorka(znak, p, n, rok, sen=False):
    casti = [f'{znak}{pct(p)} %']
    if sen or orient(rok):
        casti.append('orientačně')
    casti.append(f'nejistota ±{n} %')
    return '(' + ', '.join(casti) + ')'


def texty_oblasti(klic, h, n, min_osob, ctx):
    T = []
    vek = ctx['vek']
    if h['nula']:
        return ['V obci nežijí obyvatelé v cílovém věku (odhad pro rok 2025 je 0).']
    D0, Dmax, Dmin = zaokr_osoby(h['D0']), zaokr_osoby(h['Dmax']), zaokr_osoby(h['Dmin'])
    up, down = h['uroven'] in ('rust', 'vyrazny_rust'), h['uroven'] == 'pokles'
    sen = klic == 'sen'
    zr_up = zavorka('+', h['p_max'], n, h['t_max'], sen)
    zr_down = zavorka('−', h['p_min'], n, h['t_min'], sen)

    if klic in ('ms', 'zs'):
        skola = 'MŠ' if klic == 'ms' else 'ZŠ'
        if ctx['v_obci']:
            if up:
                cil = 'o místa v MŠ v obci' if klic == 'ms' else 'o místa na 1. stupni ZŠ v obci'
                T.append(f'Počet dětí {vek} let v obci vzroste odhadem z {D0} na {Dmax} do roku {h["t_max"]} {zr_up}. '
                         f'Očekávejte vyšší zájem {cil}.')
            elif down:
                cil = 'nižší zájem o místa v MŠ v obci' if klic == 'ms' else 'nižší naplněnost 1. stupně ZŠ v obci'
                T.append(f'Počet dětí {vek} let klesne odhadem z {D0} na {Dmin} do roku {h["t_min"]} {zr_down}. '
                         f'Lze očekávat {cil}.')
            else:
                T.append(bez_zmeny(h, n, min_osob))
        else:
            if up:
                T.append(f'Obec nemá vlastní {skola}. Dětí {vek} let přibude odhadem z {D0} na {Dmax} do roku '
                         f'{h["t_max"]} {zr_up} → z obce bude větší nápor na okolní {skola}. '
                         f'Nejbližší obec {"se ZŠ" if klic == "zs" else "s MŠ"}: {ctx["nejblizsi"]}.')
            elif down:
                T.append(f'Obec nemá vlastní {skola}. Dětí {vek} let ubude odhadem z {D0} na {Dmin} do roku '
                         f'{h["t_min"]} {zr_down} → z obce bude menší nápor na okolní {skola}.')
            else:
                T.append(f'Obec nemá vlastní {skola}. Počet dětí {vek} let se výrazně nezmění. '
                         f'Nejbližší obec {"se ZŠ" if klic == "zs" else "s MŠ"}: {ctx["nejblizsi"]}.')
    elif klic == 'pldd':
        if up:
            T.append(f'Počet dětí 0–18 let vzroste odhadem z {D0} na {Dmax} do roku {h["t_max"]} {zr_up}. '
                     f'Očekávejte vyšší zátěž dětských lékařů.')
        elif down:
            T.append(f'Počet dětí 0–18 let klesne odhadem z {D0} na {Dmin} do roku {h["t_min"]} {zr_down}. '
                     f'Lze očekávat nižší zátěž dětských lékařů.')
        else:
            T.append(bez_zmeny(h, n, min_osob))
    elif klic == 'pl':
        if up:
            T.append(f'Počet dospělých (19+) vzroste odhadem z {D0} na {Dmax} do roku {h["t_max"]} {zr_up}. '
                     f'Očekávejte vyšší zátěž praktických lékařů.')
        elif down:
            T.append(f'Počet dospělých (19+) klesne odhadem z {D0} na {Dmin} do roku {h["t_min"]} {zr_down}. '
                     f'Lze očekávat nižší zátěž praktických lékařů.')
        else:
            T.append(bez_zmeny(h, n, min_osob))
        a, b = ctx['podil'][str(ROK0)], ctx['podil']['konec']
        sloveso = 'vzroste' if b > a else ('klesne' if b < a else 'zůstane')
        if a == b:
            T.append(f'Podíl obyvatel nad 65 let mezi dospělými zůstane {a} % ({h["t_konec"]}).')
        else:
            T.append(f'Podíl obyvatel nad 65 let mezi dospělými {sloveso} z {a} % na {b} % ({h["t_konec"]}).')
    elif klic == 'sen':
        if up:
            x = ctx['top_pct']
            poradi = (f'Růst patří mezi {x} % nejvyšších v kraji.' if x <= 50
                      else 'Růst je nižší než u většiny obcí kraje.')
            T.append(f'Počet obyvatel nad 80 let vzroste odhadem z {D0} na {Dmax} do roku {h["t_max"]} {zr_up}. '
                     f'{poradi} Očekávejte vyšší potřebu pečovatelské a terénní služby.')
        elif down:
            T.append(f'Počet obyvatel nad 80 let klesne odhadem z {D0} na {Dmin} do roku {h["t_min"]} {zr_down}. '
                     f'Lze očekávat nižší potřebu pečovatelské a terénní služby.')
        else:
            T.append(bez_zmeny(h, n, min_osob))

    # vlna
    if h['vlna']:
        T.append(f'Po roce {h["t_max"]} počet klesá na {zaokr_osoby(h["vlna"]["hodnota"])} ({h["vlna"]["rok"]}) '
                 f'– jde o přechodný nárůst.')
    # konec období (pokud se liší od uvedené špičky / dna)
    uvedeny = h['t_max'] if up else (h['t_min'] if down else None)
    if h['t_konec'] != uvedeny and not (h['vlna'] and h['vlna']['rok'] == h['t_konec']):
        T.append(f'Na konci období ({h["t_konec"]}): {zaokr_osoby(h["Dkonec"])}.')
    # zařízení v obci
    if klic in ('ms', 'zs') and ctx['v_obci']:
        jedn = 'dětí' if klic == 'ms' else 'žáků'
        zar = ctx['zarizeni']
        if len(zar) <= MAX_VYPIS_ZARIZENI:
            for z in zar:
                k = f' (kapacita dle rejstříku {z["kapacita"]} {jedn})' if z['kapacita'] is not None else ''
                T.append(f'V obci: {z["nazev"]}{k}.')
        else:
            soucet = sum(z['kapacita'] or 0 for z in zar)
            T.append(f'V obci: {len(zar)} {"MŠ" if klic == "ms" else "ZŠ"} '
                     f'(součet kapacit dle rejstříku {zaokr_osoby(soucet)} {jedn}).')
    # dostupnost
    if ctx.get('spatna'):
        d = ctx['dostupnost']
        T.append(f'⚠ Nejbližší {ZARIZENI[klic]} je veřejnou dopravou {pasmo_vhd(d["vhd_min"], klic)}, '
                 f'pěšky {pasmo_pesi(d["pesi_m"])}.')
    return T


def bez_zmeny(h, n, min_osob):
    if h['duvod_ok'] == 'nejistota':
        return f'Bez výrazné změny (±{pct(h["ok_pct"])} % je v rámci nejistoty predikce ±{n} %).'
    return f'Bez výrazné změny (změna je menší než hodnocené minimum {min_osob} osob).'


def spocitej(obce, dost, skoly, nej, meta, pred, min_osob=None, hranice_vhd=HRANICE_VHD, s_texty=True):
    """Vrátí {kod: doporuceni}."""
    min_osob = min_osob or MIN_OSOB
    datum_rej = meta['datum_rejstriku']
    d_rej = '.'.join(str(int(x)) for x in reversed(datum_rej.split('-')))
    d_rej = d_rej.replace('.', '. ')
    # řady D(t) a pomocné údaje pro všechny obce
    R = {}
    for k, o in pred.items():
        R[k] = {obl[0]: rada(o, obl[3], obl[4]) for obl in OBLASTI}
        R[k]['65+'] = rada(o, 65, 100)
        R[k]['tot'] = rada(o, 0, 100)
    # 3.2 pořadí růstu 80+ v kraji (změna k maximu v %; obce s D0 = 0 se neřadí)
    g = {}
    for k in pred:
        D = R[k]['sen']; D0 = D[ROK0]
        if D0 > 0:
            g[k] = (max(D[r] for r in range(2026, 2056)) - D0) / D0 * 100
    ser = pd.Series(g)
    perc = (ser.rank(method='max', pct=True) * 100)       # 100 = nejvyšší růst
    top = ((ser.rank(method='min', ascending=False)) / len(ser) * 100).apply(math.ceil)

    out = {}
    for k, o in pred.items():
        obyv = R[k]['tot'][ROK0]
        vm = obyv > VELKE_MESTO
        vel = velikost(obyv)
        drow = dost.loc[k]
        oblasti = []
        for klic, nazev, vek_t, od, do, obdobi, _ in OBLASTI:
            n = nej[(klic, vel)]
            D = R[k][klic]
            h = hodnot(D, obdobi, n, min_osob[klic])
            ctx = {'vek': vek_t}
            obj = dict(klic=klic, nazev=nazev, vek=vek_t, obdobi=list(obdobi),
                       v_obci=None, zarizeni_v_obci=None, nejblizsi_obec=None,
                       dostupnost=None, spatna_dostupnost=None)
            zdroje = ['predikce obyvatel (hotová projekce 2025–2055)',
                      'backtest predikce (nejistota)']
            # zařízení (rejstřík)
            if klic in ('ms', 'zs'):
                v_obci = bool(drow[f'ma_{klic}'])
                rozpor = bool(drow[f'rozpor_{klic}'])
                druh = 'MS' if klic == 'ms' else 'ZS'
                sk = skoly[(skoly.kod == k) & (skoly.druh == druh)].drop_duplicates('izo')
                zar = [dict(nazev=r.nazev_po, kapacita=nint(r.kapacita_skoly)) for r in sk.itertuples()]
                obj['v_obci'] = v_obci
                obj['zarizeni_v_obci'] = zar
                obj['nejblizsi_obec'] = None if v_obci else drow[f'nejblizsi_obec_{klic}']
                ctx.update(v_obci=v_obci, zarizeni=zar, nejblizsi=obj['nejblizsi_obec'])
                zdroje.append(f'rejstřík škol MŠMT {d_rej}')
                hodnotit_dost = (not vm) and (not v_obci) and (not rozpor)
            elif klic in ('pldd', 'pl'):
                hodnotit_dost = not vm
            else:
                hodnotit_dost = False
            if hodnotit_dost:
                d = dict(auto_min=nint(drow[f'{klic}_auto_min']), vhd_min=nint(drow[f'{klic}_vhd_min']),
                         pesi_m=nint(drow[f'{klic}_pesi_m']))
                spatna = d['vhd_min'] is None or d['vhd_min'] > hranice_vhd
                obj['dostupnost'] = d
                obj['spatna_dostupnost'] = spatna
                ctx.update(dostupnost=d, spatna=spatna)
                zdroje.append(VRSTVA[klic])
            obj['rada'] = dict(roky=h['roky'], hodnoty=[round(x, 1) for x in h['hod']])
            obj['stav_2025'] = dict(rok=ROK0, hodnota=round(h['D0'], 1))
            obj['max'] = dict(rok=h['t_max'], hodnota=round(h['Dmax'], 1))
            obj['min'] = dict(rok=h['t_min'], hodnota=round(h['Dmin'], 1))
            obj['konec'] = dict(rok=h['t_konec'], hodnota=round(h['Dkonec'], 1))
            for a in ('max', 'min', 'konec'):
                v = h[f'p_{a}']
                obj[f'zmena_pct_{a}'] = None if v is None else round(v, 1)
            obj['nejistota_pct'] = n
            obj['uroven'] = h['uroven']
            if klic == 'pl':
                D19 = R[k]['pl']; D65 = R[k]['65+']
                kon = obdobi[1]
                podil = {str(ROK0): int(round(D65[ROK0] / D19[ROK0] * 100)) if D19[ROK0] > 0 else None,
                         'konec': int(round(D65[kon] / D19[kon] * 100)) if D19[kon] > 0 else None}
                obj['podil_65_plus'] = podil
                ctx['podil'] = podil
            if klic == 'sen':
                obj['poradi_kraj_pct'] = None if k not in perc else int(round(perc[k]))
                ctx['top_pct'] = None if k not in top else int(top[k])
            if s_texty:
                obj['texty'] = texty_oblasti(klic, h, n, min_osob[klic], ctx)
            obj['zdroje'] = zdroje
            obj['_h'] = h          # interní, před zápisem se odstraní
            oblasti.append(obj)
        out[k] = dict(velke_mesto=vm, varovani=VAROVANI if vm else None, oblasti=oblasti)
    return out


def zapis(out, pred, OUT):
    os.makedirs(OUT + 'obce', exist_ok=True)
    for k, o in pred.items():
        dop = copy.deepcopy(out[k])
        for ob in dop['oblasti']:
            ob.pop('_h', None)
        o2 = dict(o)
        o2['doporuceni'] = dop
        with open(f'{OUT}obce/{k}.json', 'w', encoding='utf-8') as f:
            f.write(json.dumps(o2, ensure_ascii=False, separators=(',', ':'), allow_nan=False))


if __name__ == '__main__':
    OUT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/out/'
    obce, dost, skoly, nej, meta, pred = nacti_vstupy(OUT)
    out = spocitej(obce, dost, skoly, nej, meta, pred)
    zapis(out, pred, OUT)
    print('zapsáno', len(out), 'obcí')
