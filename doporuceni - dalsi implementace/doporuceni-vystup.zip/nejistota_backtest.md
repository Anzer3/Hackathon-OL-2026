## 3.3 Nejistota z backtestu

### 80. percentil chyby obcí (T = 2012 → 2020, 8 let, model s faktory), %

| skupina   |   < 500 |   500–1 999 |   2 000+ |
|:----------|--------:|------------:|---------:|
| 0-14      |    30.2 |        19.4 |     10.3 |
| 15-64     |    11.5 |         7.7 |      4.9 |
| 65+       |    16.4 |        11.8 |      5.9 |

Pro srovnání průměr (MAPE) – musí sedět s backtest-vysledky.md:

| skupina   |   < 500 |   500–1 999 |   2 000+ |
|:----------|--------:|------------:|---------:|
| 0-14      |   18.83 |       11.8  |     6.67 |
| 15-64     |    7.34 |        4.67 |     3.12 |
| 65+       |   11.46 |        7.33 |     4.13 |

### Poměr chyby úzké skupiny k celé skupině (ORP, predikce obcí sečtená do ORP)

Kontrola: součet predikce obcí vs. součet ORP se liší max. o 2.06 % (rozdíl = chyba predikce celku, ne chyba vazby).

| oblast   | skupina   |   chyba_uzke |   chyba_skupiny |   pomer |
|:---------|:----------|-------------:|----------------:|--------:|
| ms       | 0-14      |         4.93 |            3.07 |    1.6  |
| zs       | 0-14      |         2.17 |            3.07 |    0.71 |
| pldd     | 0-14      |         2.75 |            3.07 |    0.89 |
| pl       | 15-64     |         0.62 |            0.65 |    0.96 |
| sen      | 65+       |         3.26 |            1.73 |    1.89 |

### Výsledná nejistota (nejistota.csv), %

| oblast   |   < 500 |   500–1 999 |   2 000+ |
|:---------|--------:|------------:|---------:|
| ms       |      48 |          31 |       17 |
| pl       |      11 |           7 |        5 |
| pldd     |      27 |          17 |        9 |
| sen      |      31 |          22 |       11 |
| zs       |      21 |          14 |        7 |

## 7.2 Zpětná trefa (T = 2012, roky 2013–2020)

**0-14:** směr doporučení sedí v **69 %** obcí (398 obcí)

| predikce   |   bez změny |   pokles |   růst |
|:-----------|------------:|---------:|-------:|
| bez změny  |         267 |       27 |     94 |
| pokles     |           2 |        2 |      0 |
| růst       |           2 |        0 |      4 |

Podle velikosti: 500–1 999: 68 %, 2 000+: 80 %, < 500: 66 %

**65+:** směr doporučení sedí v **80 %** obcí (398 obcí)

| predikce   |   bez změny |   pokles |   růst |
|:-----------|------------:|---------:|-------:|
| bez změny  |          55 |        4 |     39 |
| růst       |          32 |        3 |    265 |

Podle velikosti: 500–1 999: 87 %, 2 000+: 100 %, < 500: 67 %

**Celkem:** směr sedí v 74 % případů (obec × skupina).
